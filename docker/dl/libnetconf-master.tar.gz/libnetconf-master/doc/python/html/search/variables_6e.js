var searchData=
[
  ['netconfv1_5f0',['NETCONFv1_0',['../namespacenetconf.html#a8773b2610e0b3ecada9d4ffff0c8b2bf',1,'netconf']]],
  ['netconfv1_5f1',['NETCONFv1_1',['../namespacenetconf.html#af6594393ab323d02b1429f49f2561699',1,'netconf']]]
];
