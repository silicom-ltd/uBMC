var group__gen_a_p_i =
[
    [ "NC_MSG_TYPE", "d3/d35/group__gen_a_p_i.html#ga298c7a4ad5cc76169a211f86df90f057", [
      [ "NC_MSG_UNKNOWN", "d3/d35/group__gen_a_p_i.html#gga298c7a4ad5cc76169a211f86df90f057a43e894ea69b22c6080016fe210da4305", null ],
      [ "NC_MSG_WOULDBLOCK", "d3/d35/group__gen_a_p_i.html#gga298c7a4ad5cc76169a211f86df90f057a5b0ce1ca54b15ef3ca1ef901263c1b72", null ],
      [ "NC_MSG_NONE", "d3/d35/group__gen_a_p_i.html#gga298c7a4ad5cc76169a211f86df90f057a1272e268199e52e368957b6a3b288d50", null ],
      [ "NC_MSG_HELLO", "d3/d35/group__gen_a_p_i.html#gga298c7a4ad5cc76169a211f86df90f057a7cd0f4a4edef33489e675b080645288d", null ],
      [ "NC_MSG_RPC", "d3/d35/group__gen_a_p_i.html#gga298c7a4ad5cc76169a211f86df90f057a7f6951d98d30342a65e6b1d7ccca2df0", null ],
      [ "NC_MSG_REPLY", "d3/d35/group__gen_a_p_i.html#gga298c7a4ad5cc76169a211f86df90f057a827b3c9c898a48ec8e9f8f9af11f1bdd", null ],
      [ "NC_MSG_NOTIFICATION", "d3/d35/group__gen_a_p_i.html#gga298c7a4ad5cc76169a211f86df90f057ab4e4b148e14bdf9f320331b0cbe1dc6d", null ]
    ] ],
    [ "NC_VERB_LEVEL", "d3/d35/group__gen_a_p_i.html#ga921d994eb69a9efd93ef85cf4a6cd060", [
      [ "NC_VERB_ERROR", "d3/d35/group__gen_a_p_i.html#gga921d994eb69a9efd93ef85cf4a6cd060a908c5d51b81e0ab37d2c57e569446d9b", null ],
      [ "NC_VERB_WARNING", "d3/d35/group__gen_a_p_i.html#gga921d994eb69a9efd93ef85cf4a6cd060a4a0cbb6bc660d3a50c3dff6028185abf", null ],
      [ "NC_VERB_VERBOSE", "d3/d35/group__gen_a_p_i.html#gga921d994eb69a9efd93ef85cf4a6cd060ae023b386220c2337dc9a556f5c669172", null ],
      [ "NC_VERB_DEBUG", "d3/d35/group__gen_a_p_i.html#gga921d994eb69a9efd93ef85cf4a6cd060a1ddf66190b3b38c4de213321e3ae6491", null ]
    ] ],
    [ "nc_callback_print", "d3/d35/group__gen_a_p_i.html#ga806dfa9c27d2b8076bae21bcd549cce7", null ],
    [ "nc_close", "d3/d35/group__gen_a_p_i.html#gaaf2f5bf5a58103d9e4ea1cbe4291094b", null ],
    [ "nc_datetime2time", "d3/d35/group__gen_a_p_i.html#ga4dfd796fda30d3ad8588b4c30c4c1583", null ],
    [ "nc_err_dup", "d3/d35/group__gen_a_p_i.html#ga316faef1140f1b48a2ed1de6d84d2bef", null ],
    [ "nc_err_free", "d3/d35/group__gen_a_p_i.html#gac4bd51febe24b517d1952d1c1d8f6b07", null ],
    [ "nc_err_get", "d3/d35/group__gen_a_p_i.html#ga3d7714f1f56ac7203a80c61aea4344f8", null ],
    [ "nc_err_new", "d3/d35/group__gen_a_p_i.html#ga057524ba5256c428b6bf88710f000e0c", null ],
    [ "nc_err_set", "d3/d35/group__gen_a_p_i.html#gab28d881eeebd79d485391ae1ffc97299", null ],
    [ "nc_hello_timeout", "d3/d35/group__gen_a_p_i.html#ga8549cab822104310917fca804476d272", null ],
    [ "nc_init", "d3/d35/group__gen_a_p_i.html#ga40e32bd7c1404a76105b426219021cdc", null ],
    [ "nc_msgid_compare", "d3/d35/group__gen_a_p_i.html#gae160a70158f957344eb3204987329632", null ],
    [ "nc_time2datetime", "d3/d35/group__gen_a_p_i.html#ga90a44b60b04512fd0a3507ab35a1ccc4", null ],
    [ "nc_verb_error", "d3/d35/group__gen_a_p_i.html#gabd4e3697f3a1fe6b5853e692ad20c2bb", null ],
    [ "nc_verb_verbose", "d3/d35/group__gen_a_p_i.html#gae4f0d22fb274269c0259497abb702f5d", null ],
    [ "nc_verb_warning", "d3/d35/group__gen_a_p_i.html#ga943a7c859f20bb1278964a7424762d8e", null ],
    [ "nc_verbosity", "d3/d35/group__gen_a_p_i.html#gadd8fd7b3bb2e7cba580c9a4229fe02d7", null ]
];