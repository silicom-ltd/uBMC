var structtransapi =
[
    [ "clbks_order", "d9/dc0/structtransapi.html#a9da1a4a7373fb09e2f82fb7f1a81f9b2", null ],
    [ "close", "d9/dc0/structtransapi.html#a414e48f893be7474f64d2c61a9c012b9", null ],
    [ "config_modified", "d9/dc0/structtransapi.html#aa234e35582e991cd6e5c43047e315528", null ],
    [ "data_clbks", "d9/dc0/structtransapi.html#a44e5e883d6586faf97047d23c7bcebf7", null ],
    [ "erropt", "d9/dc0/structtransapi.html#acb50180a0bc032bef4b6af94d8596528", null ],
    [ "file_clbks", "d9/dc0/structtransapi.html#a829682c0ae04089a665f2de8f1378446", null ],
    [ "get_state", "d9/dc0/structtransapi.html#a6c403c3ae7c1ca5654fdaf60b60ba16b", null ],
    [ "init", "d9/dc0/structtransapi.html#a8cb29ceda55d20ecbec3784d536851db", null ],
    [ "ns_mapping", "d9/dc0/structtransapi.html#a517eb18d6321490a3439ae595edbf9a4", null ],
    [ "rpc_clbks", "d9/dc0/structtransapi.html#ae40968626e78bf37871565d98292b1b7", null ],
    [ "version", "d9/dc0/structtransapi.html#aad880fc4455c253781e8968f2239d56f", null ]
];