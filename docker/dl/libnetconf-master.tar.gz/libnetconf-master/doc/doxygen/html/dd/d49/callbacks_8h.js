var callbacks_8h =
[
    [ "nc_callback_error_reply", "dd/d49/callbacks_8h.html#ga771a110143440bcd3b7d4c0e98388e80", null ],
    [ "nc_callback_print", "dd/d49/callbacks_8h.html#ga806dfa9c27d2b8076bae21bcd549cce7", null ]
];