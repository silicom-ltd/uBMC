var group__callhome =
[
    [ "nc_callhome_accept", "db/de7/group__callhome.html#ga556966a9c54e814e02b4afadf128b9b7", null ],
    [ "nc_callhome_connect", "db/de7/group__callhome.html#ga5c1437b22b1ccac95d0ba15c34912f78", null ],
    [ "nc_callhome_listen", "db/de7/group__callhome.html#gafa8e04fb09dcafcd7c06d086e835f25f", null ],
    [ "nc_callhome_listen_stop", "db/de7/group__callhome.html#ga93a36d2d6c0e1d1eb0c65d70c6ded3cc", null ],
    [ "nc_callhome_mngmt_server_add", "db/de7/group__callhome.html#gaa08ac6e90c2b70dd2461bab461f3ed08", null ],
    [ "nc_callhome_mngmt_server_free", "db/de7/group__callhome.html#ga3db211a665c56160c167619b633b6cb0", null ],
    [ "nc_callhome_mngmt_server_getactive", "db/de7/group__callhome.html#ga8b22e5afbc118e69b42b0f66388f56ab", null ],
    [ "nc_callhome_mngmt_server_rm", "db/de7/group__callhome.html#ga1c2942e68d263d674adf1381bc5e7083", null ]
];